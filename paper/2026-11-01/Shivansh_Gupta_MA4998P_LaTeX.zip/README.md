# Weighted Federated Synthetic Data Generation

35-page MA4998P Project I report, Department of Mathematics, IIT Guwahati, November 2026.

Student: Shivansh Gupta (230123058). Supervisor: Dr. Partha Sarathi Mandal.

## Compile

Use pdfLaTeX with BibTeX, or upload this ZIP to Overleaf and choose report.tex as the main file. From the unzipped directory:

    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex

The figures, official template logo and bibliography are included; compiling the report requires no data download, model training or GitHub access. The PDF in the ZIP is the reviewed copy. The certificate is unsigned. Both mandated Turnitin fields are blank for the actual checks on this revision.

## Contents and evidence

- chapters/: dataset and qualitative question, mathematics, protocol, six studies, theoretical guarantees, conclusion and acknowledgement, evidence appendix.
- tables/: expanded development candidates table.
- figures/: the four plotted figures used in the document (vector PDFs).
- evidence/: saved numerical summaries used in the project; the CSVs are not raw training data. They retain the original repository's work-package numbering.
- scripts/: optional Python scripts (matplotlib, pandas, numpy) to regenerate the figures and check arithmetic examples. Run scripts/rebuild_report_figures.py for the three existing study figures; scripts/plot_projection.py rebuilds the new paired correction figure.
- supplement/: separate eight-page proof supplement, editable LaTeX, Markdown text and proof review. Its 27 statements include post-experiment theory, as stated in the report.
- references.bib: source bibliography; BibTeX includes only works cited.
- SHA256SUMS.txt: integrity hashes of the packaged members other than this manifest.

Evidence snapshot: https://github.com/S-G-mathematics/btp-federated-synthetic-data/tree/f1624441be8554649b8b2dfcfbf24e05d947dc98
The six study groups consolidate twelve archived work packages; this edition reports existing experiments and adds no fit or holdout evaluation.
