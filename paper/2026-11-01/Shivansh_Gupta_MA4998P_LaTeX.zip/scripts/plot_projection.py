"""Plot the same-row education-code comparison from the archived summary."""
from pathlib import Path
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
root = Path(__file__).resolve().parents[1]
with (root / "evidence/projection_mechanism.csv").open() as fd:
    rows = [r for r in csv.DictReader(fd) if r["method"] == "size"]
assert len(rows) == 4 and all(int(r["draws"]) == 15 for r in rows)
fig, ax = plt.subplots(figsize=(6.0, 2.25), layout="constrained")
for y, r in enumerate(rows[::-1]):
    a, b = float(r["mean_raw_loss"]), float(r["mean_projected_loss"])
    ax.plot([b, a], [y, y], lw=1.8, color="#9DAFBB")
    ax.scatter(a, y, c="#9C4B21", marker="D", s=42, zorder=3)
    ax.scatter(b, y, c="#13685F", marker="o", s=54, zorder=3)
labels = [("Chow–Liu" if r["generator"]=="chow_liu" else "Mixed GMM") + (" · age, K=5" if r["partition"] == "age" else " · label, K=10") for r in rows[::-1]]
ax.set_yticks(range(4),labels, fontsize=9); ax.set_xlim(0,.76); ax.set_ylim(-.5,3.5)
ax.set_xlabel("Maximum absolute query error",fontsize=10)
ax.spines[["right","top","left"]].set_visible(False); ax.tick_params(axis="y",length=0)
ax.set_axisbelow(True);ax.grid(axis="x",alpha=.17)
ax.legend(handles=[Line2D([],[],ls="",marker="D",color="#9C4B21",label="Raw rows"),Line2D([],[],ls="",marker="o",color="#13685F",label="After code correction")],loc="lower center",bbox_to_anchor=(.52,1.0),ncol=2,frameon=False,fontsize=9)
fig.savefig(root/"figures/projection.pdf")
