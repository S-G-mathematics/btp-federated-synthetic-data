#!/usr/bin/env python3
"""Rebuild manuscript tables/figures from copied, previously scored evidence.

No raw-data access, fitting, method selection, or test rescoring occurs here.
"""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
E, T, F = (ROOT / p for p in ('evidence', 'tables', 'figures'))
for p in (T, F, ROOT/'checks'):
    p.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.labelsize':8,
                     'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
                     'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,
                     'axes.spines.right':False,'savefig.bbox':'tight'})
COLORS = {'chow_liu':'#2166ac','copula':'#1b7837','mixed_gmm':'#8e3b76'}
GN = {'chow_liu':'Chow--Liu','copula':'Copula','mixed_gmm':'Mixed GMM'}
PN = {'age':'Age','age_education':'Age + education','label_skew':'Label skew'}
def df(n): return pd.read_csv(E/n)
def savefig(fig,name):
    fig.savefig(F/(name+'.pdf'))
    fig.savefig(F/(name+'.png'),dpi=200)
    plt.close(fig)

plt.rcParams.update({'font.size':10,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8})
sl=df('adult_development_slices.csv');sl=sl[(sl.method=='constrained') & sl.generator.isin(GN)].copy()
cs=df('adult_confirmation_slices.csv');bs=df('bank_external_slices.csv')
fig,axes=plt.subplots(3,1,figsize=(5.2,6.7),layout='constrained',sharey=True)
order=[('age',5),('age',10),('age_education',5),('age_education',10),('label_skew',5),('label_skew',10)]
for ax,g in zip(axes,['copula','chow_liu','mixed_gmm']):
    d=sl[sl.generator==g].set_index(['partition','k']).loc[order]
    y=np.arange(6);x=d.mean_paired_delta.to_numpy()
    ax.errorbar(x,y,xerr=np.vstack([x-d.min_paired_delta.to_numpy(),d.max_paired_delta.to_numpy()-x]),fmt='o',color=COLORS[g],capsize=2,ms=4)
    ax.axvline(0,color='#555555',lw=.7);ax.axvline(-.005,color='#b2182b',ls='--',lw=1)
    ax.set_title(GN[g].replace('--','–'),fontsize=10);ax.set_xlabel('Constrained − size')
    ax.grid(axis='x',alpha=.18)
axes[0].set_yticks(np.arange(6),[f'{PN[p]}, K={k}' for p,k in order]);axes[0].invert_yaxis()
savefig(fig,'development_slices')
fig,axs=plt.subplots(2,1,figsize=(5.2,5.5),layout='constrained')
for ax,ds,label in [(axs[0],cs,'Adult official holdout'),(axs[1],bs,'Bank external assessment')]:
    x=ds.constrained_minus_size.to_numpy() if ds is cs else ds.mean_constrained_minus_size.to_numpy()
    labs=[f'{PN[r.partition]}, K={r.k}' for r in ds.itertuples()] if ds is cs else [f'{GN[r.generator].replace("--","–")} / {PN[r.partition]}' for r in ds.itertuples()]
    ax.scatter(x,np.arange(len(x)),color='#2166ac',s=24)
    ax.set_yticks(np.arange(len(x)),labs);ax.invert_yaxis();ax.axvline(0,color='#555',lw=.7)
    ax.axvline(-.005,color='#b2182b',ls='--',lw=1);ax.set_xlim(-.0058,.0015);ax.grid(axis='x',alpha=.15)
    ax.set_title(label,fontsize=10);ax.set_xlabel('Constrained − size query-max')
savefig(fig,'confirmation_external')
sz=df('synthetic_size_by_family.csv');pi=df('pilot_size_by_family.csv')
fig,axs=plt.subplots(3,1,figsize=(5.2,6.7),layout='constrained')
for fam,c,label in [('chow_liu_age_k5',COLORS['chow_liu'],'Chow–Liu: age/K5'),('mixed_gmm_label_skew_k10',COLORS['mixed_gmm'],'GMM: label skew/K10')]:
    a=sz[sz.family==fam].sort_values('m');b=pi[pi.family==fam].sort_values('pilot_per_client')
    axs[0].plot(a.m,a.size_query_mean,'o-',color=c,label=label,ms=3)
    axs[1].plot(a.m,a.size_query_draw_range_mean,'o-',color=c,ms=3)
    axs[2].plot(b.pilot_per_client,b.same_target_fixed_reference_excess_mean,'o-',color=c,ms=3)
for ax,title in zip(axs,['Size-weighted query-max','Five-draw loss range','Finite-reference LP excess']):
    ax.set_xscale('log');ax.set_title(title,fontsize=8);ax.grid(alpha=.2)
axs[0].set_xlabel('Synthetic rows');axs[1].set_xlabel('Synthetic rows');axs[2].set_xlabel('Pilot rows/client')
axs[0].legend(loc='best',fontsize=8)
savefig(fig,'sampling_pilot')
fe=df('female_dependency_worst_query.csv')
assert len(fe)==12 and (fe.real_alpha_conditional==0).all()
assert np.isclose(fe.absolute_error.mean(),.375)
fe=fe.sort_values('cell')
labs=[]
for s in fe.cell:
    t=s.replace('copula_','').replace('age_education','Age+edu').replace('label_skew','Label').replace('age','Age').replace('_',' / ')
    labs.append(t)
fig,ax=plt.subplots(figsize=(5.2,4.2),layout='constrained')
ax.barh(np.arange(12),fe.synthetic,color='#ad5555',height=.65)
ax.set_yticks(np.arange(12),labs,fontsize=8);ax.invert_yaxis();ax.set_xlim(0,.44)
ax.set_xlabel('Generated frequency (real reference = 0)');ax.grid(axis='x',alpha=.16)
savefig(fig,'female_dependency')
