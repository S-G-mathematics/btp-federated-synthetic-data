# IIT Guwahati BTP: IEEE manuscript and reproducible writing package

This package contains the complete research manuscript in the unmodified IEEEtran **journal** format, with proofs, results, limitations, references, and technical appendices. No target IEEE venue or page limit was supplied. It is not an acceptance, publication, or assertion of compliance with an unspecified journal's additional requirements.

**Author:** Shivansh Gupta, IIT Guwahati, following the supplied author-ready pack. Confirm the final author list, supervisor/coauthor participation, acknowledgments, disclosure requirements, and target venue before submitting. No author, funding, ethics approval, contact address, or GitHub URL has been invented.

## Read and edit

- `BTP_IEEE_Manuscript.pdf`: compiled paper, including all proofs and appendices.
- `BTP_IEEE_Manuscript.tex`: main LaTeX entry point.
- `sections/`: editable paper sections and complete mathematical treatment.
- `references.bib`: numbered IEEE bibliography input.
- `figures/`: vector scientific figures and reading PNGs.
- `tables/`: generated LaTeX tables and derived descriptive summaries.
- `evidence/`: copied author-pack CSVs, the global freeze, workload, closure register, and additional all-method development table.
- `checks/`: manuscript checks, evidence reproduction, and mathematical finite-algebra diagnostics.

The article retains the fixed-target comparative negative finding, all twelve completed work-package scopes, all null and adverse outcomes, and the main pipeline's nonprivate status. No new fitting, selection, raw-data access, or official-test scoring was performed during manuscript preparation.

## Theory status

The manuscript completes the finite mathematical analysis: mixture geometry, identifiability counterexample, sharp representation bound, empirical decomposition, subset collapse, oracle perturbation, regularization stability, stratified sample bounds, a sufficient fallback certificate, target-summary and validation error, projected pushforwards, conditional routing/transfer, support and student filtering, bounded-risk/Brier transfer, finite-support/geometric/transport approximations, and conditional privacy composition. Proofs and counterexamples are provided.

The uncertainty-aware fallback is an **analytical extension written after the completed experiments**, not the historical selection procedure or an experimentally validated new algorithm. The population and DP implications explicitly require premises that the main experiment does not establish. They must not be converted into empirical claims during editing. The finite-algebra check is a diagnostic, not a proof and not an additional experiment.

## Rebuild

Requirements: TeX Live with `latexmk`, `pdflatex`, BibTeX, AMS packages, graphicx, booktabs, tabularx, multirow, cite, hyperref, microtype, balance; Python with numpy, pandas, matplotlib, scipy. Original `IEEEtran.cls` and `IEEEtran.bst` are included with their notices and README.

```bash
bash build.sh
```

For a LaTeX-only Overleaf build, upload the entire source ZIP and choose `BTP_IEEE_Manuscript.tex` as the main file; pre-generated tables and figures are already included. Python is required only to regenerate table/figure artifacts or run the supplementary checks.

## Evidence and full experimental archive

The separately delivered full executable experimental archive is `BTP_FINAL_EXPERIMENTAL_PACKAGE_20261025_v2.zip`, reported SHA-256 `b184b0b07d3185ca7bd95322fd7bf432b28293b1041f5cae5cc9153ead25b2bf` and size 537,318,039 bytes. It was not attached in this writing environment. This manuscript package **does not claim to contain that archive**, raw datasets, or every model checkpoint.

The current writing uses the verified documentation/results review ZIP and the verified author-ready addendum. Main statistics are reaggregated from copied saved CSVs; the results audit and its limitations are described in Appendix F of the manuscript (appendix lettering may change with editing). Historical source tests are reported as recorded execution evidence, not claimed to have been rerun here.

The official Adult test and seeds 404/505 have already been used after the written global freeze. They are no longer untouched confirmation data. Do not change or reselect the method using those outcomes. Additional research would need a separate protocol and evidence source.

GitHub creation and publication were left aside following the user's correction. No repository or paper was published.

## Attribution

UCI Adult and Bank sources, primary methodology papers, and adapted references are cited in the paper. IEEEtran files preserve their original license notices. This writing package contains research material with different underlying attribution obligations; it does not assign a blanket license to all upstream content or the separately archived experiments.
