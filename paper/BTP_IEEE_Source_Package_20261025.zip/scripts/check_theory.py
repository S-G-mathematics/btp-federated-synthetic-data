#!/usr/bin/env python3
"""Finite-algebra sanity checks, not empirical experiments or theorem proofs."""
from pathlib import Path
import json, math
import numpy as np
from scipy.optimize import linprog

rng=np.random.default_rng(20261025)
checks={}
def ok(name, condition):
    if not bool(condition): raise AssertionError(name)
    checks[name]=True
def simplex(n): return rng.dirichlet(np.ones(n))
def tv(a,b):return np.abs(a-b).sum()/2
def allocate(w,m):
    raw=w*m;n=np.floor(raw).astype(int)
    ix=np.argsort(-(raw-n),kind='stable');n[ix[:m-int(n.sum())]]+=1
    return n
def lp(H,b,alpha=None,radius=None):
    L,K=H.shape
    if radius is None:
        A=np.vstack([np.c_[H,-np.ones(L)],np.c_[-H,-np.ones(L)]])
        out=linprog(np.r_[np.zeros(K),1],A_ub=A,b_ub=np.r_[b,-b],
                    A_eq=np.array([np.r_[np.ones(K),0]]),b_eq=[1],bounds=[(0,None)]*(K+1),method='highs')
        assert out.success
        return out.x[:K]
    raise NotImplementedError
for trial in range(100):
    K,L,Z=5,9,17
    H=rng.random((L,K));a=simplex(K);w=simplex(K);v=w-a
    diam=np.max(np.ptp(H,axis=1))
    ok(f'representation_{trial}',np.max(abs(H@v))<=diam*np.abs(v).sum()/2+1e-12)
    b=rng.random(L);dh=rng.uniform(-.03,.03,H.shape);db=rng.uniform(-.02,.02,L)
    Hh=H+dh;bh=b+db;rr=np.max(abs(dh))+np.max(abs(db))
    est=lp(Hh,bh);opt=lp(H,b)
    ok(f'oracle_{trial}',np.max(abs(H@est-b))-np.max(abs(H@opt-b))<=2*rr+1e-10)
    n=allocate(w,103)
    ok(f'allocation_{trial}',n.sum()==103 and np.max(abs(n/103-w))<1/103+1e-14)
    P=simplex(Z);Q=simplex(Z);C=rng.random(Z)>.5
    if not C.any():C[0]=True
    qs=rng.random((L,Z));rp=P[C].sum();sp=Q[C].sum()
    ec=np.max(abs(qs[:,C]@(P[C]-Q[C])));em=abs(rp-sp)
    actual=np.max(abs(qs[:,C]@(P[C]/rp-Q[C]/sp)))
    ok(f'conditional_{trial}',actual<=min(1,(ec+em)/rp)+1e-12)
    mp=np.zeros(Z);mp[C]=P[C]/rp
    ok(f'filtering_{trial}',abs(tv(P,mp)-(1-rp))<1e-12)
    targets=rng.integers(0,7,Z)
    Pt=np.bincount(targets,weights=P,minlength=7);Qt=np.bincount(targets,weights=Q,minlength=7)
    ok(f'pushforward_{trial}',abs(Pt.sum()-1)<1e-12 and tv(Pt,Qt)<=tv(P,Q)+1e-12)
    p=simplex(12).reshape(6,2);q=simplex(12).reshape(6,2)
    g=rng.random(6);eta=p[:,1]/p.sum(1);etab=q[:,1]/q.sum(1)
    def risk(p,g):return np.sum(p[:,0]*g*g+p[:,1]*(1-g)**2)
    gap=np.sum(p.sum(1)*(g-eta)**2)
    ok(f'brier_identity_{trial}',abs(risk(p,g)-risk(p,eta)-gap)<1e-12)
    ag=np.sum(q.sum(1)*(g-etab)**2)
    ok(f'brier_transfer_{trial}',gap<=ag+2*tv(p.flatten(),q.flatten())+1e-12)
    h=rng.normal(size=Z);hp=h+rng.uniform(-.1,.1,Z)
    pp=np.exp(h-h.max());pp/=pp.sum();qq=np.exp(hp-hp.max());qq/=qq.sum()
    eta_log=max(abs(hp-h))
    ok(f'logpool_{trial}',tv(pp,qq)<=min(1,(np.exp(2*eta_log)-1)/2)+1e-12)
    # Explicit empirical fallback comparison under bounded matrix perturbation.
    improvement=np.max(abs(Hh@a-bh))-np.max(abs(Hh@est-bh))
    kappa=.005
    if improvement>=kappa+2*rr:
        ok(f'fallback_model_{trial}',np.max(abs(H@est-b))<=np.max(abs(H@a-b))-kappa+1e-12)

# Sharpness and counterexamples are exact finite constructions.
ok('representation_sharp',np.isclose(np.array([0.,1.])@np.array([-.125,.125]),.25/2))
R=np.array([.5,0,0,.5]);S=np.array([0,.5,.5,0])
qx=np.array([0,0,1,1]);qy=np.array([0,1,0,1])
ok('marginal_counterexample',qx@R==qx@S and qy@R==qy@S and tv(R,S)==1)
radius=math.sqrt(math.log(2*10*152/.01)/(2*1500))
ok('pilot_radius_illustration',.064<radius<.066)
out={'purpose':'finite algebra diagnostics; proofs are in the manuscript',
     'checks_passed':len(checks),'all_passed':True,'seed':20261025,
     'illustrative_pilot_radius':radius,'checks':checks}
root=Path(__file__).resolve().parents[1]
(root/'checks'/'theory_sanity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
