#!/usr/bin/env python3
"""Rebuild manuscript tables/figures from copied, previously scored evidence.

No raw-data access, fitting, method selection, or test rescoring occurs here.
"""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
E, T, F = (ROOT / p for p in ('evidence', 'tables', 'figures'))
for p in (T, F, ROOT/'checks'):
    p.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.labelsize':8,
                     'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
                     'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,
                     'axes.spines.right':False,'savefig.bbox':'tight'})
COLORS = {'chow_liu':'#2166ac','copula':'#1b7837','mixed_gmm':'#8e3b76'}
GN = {'chow_liu':'Chow--Liu','copula':'Copula','mixed_gmm':'Mixed GMM'}
PN = {'age':'Age','age_education':'Age + education','label_skew':'Label skew'}
def df(n): return pd.read_csv(E/n)
def savefig(fig,name):
    fig.savefig(F/(name+'.pdf'))
    fig.savefig(F/(name+'.png'),dpi=200)
    plt.close(fig)
def table(name,caption,label,columns,header,rows,wide=False,note=''):
    env='table*' if wide else 'table'
    text='\\begin{'+env+'}[t]\n\\centering\\footnotesize\n'
    text+='\\caption{'+caption+'}\\label{'+label+'}\n'
    text+='\\begin{tabular}{'+columns+'}\\toprule\n'
    text+=' & '.join(header)+'\\\\\\midrule\n'
    text+='\n'.join(' & '.join(map(str,r))+'\\\\' for r in rows)
    text+='\n\\bottomrule\\end{tabular}\n'
    if note:text+='\\par\\vspace{3pt}\\begin{minipage}{'+('\\textwidth' if wide else '\\columnwidth')+'}\\footnotesize '+note+'\\end{minipage}\n'
    text+='\\end{'+env+'}\n'
    (T/(name+'.tex')).write_text(text)

dev=df('adult_development_cell_methods.csv')
core=dev[dev.generator.isin(GN)]
dc=core[core.method=='constrained']
assert len(dc)==54 and dc.cell.nunique()==54
assert np.isclose(dc.paired_delta_vs_size.mean(),.002427902586662067,atol=1e-12)
sl=df('adult_development_slices.csv')
sl=sl[(sl.method=='constrained') & sl.generator.isin(GN)].copy()
assert len(sl)==18 and not (sl.mean_paired_delta<=-.005).any()
conf=df('adult_confirmation_all_draws.csv')
assert len(conf)==180 and conf.cell.nunique()==12
assert (conf.n_synthetic==10000).all() and (conf.n_real_reference==16281).all()
assert conf.groupby(['cell','method']).size().eq(5).all()
cmeans=conf.groupby(['cell','method']).query_linf.mean().unstack()
cdiff=cmeans.constrained-cmeans['size']
assert np.isclose(cdiff.mean(),-.00021490707600188447,atol=1e-12)
assert np.isclose(cmeans['size'].mean(),.0222157202732753,atol=1e-12)
cs=df('adult_confirmation_slices.csv')
bs=df('bank_external_slices.csv')
assert len(cs)==6 and not (cs.constrained_minus_size<=-.005).any()
assert len(bs)==4 and not (bs.mean_constrained_minus_size<=-.005).any()
assert np.isclose(bs.mean_constrained_minus_size.mean(),-.00133174917234375,atol=1e-12)
table('headline','Registered fixed-target comparison. Negative differences favour constrained weighting. Practical-gain counts use the declared slice means.','tab:headline','lrrr',
      ['Evidence','Cells','Mean $\\Delta$','Gain slices'],
      [['Adult development',54,f'{dc.paired_delta_vs_size.mean():+.6f}','0/18'],
       ['Adult confirmation',12,f'{cdiff.mean():+.6f}','0/6'],
       ['Bank replication',12,f'{bs.mean_constrained_minus_size.mean():+.6f}','0/4']],
      note='Margin: $\\Delta\\le-0.005$. Adult development uses three seeds per slice; Adult confirmation uses two; Bank uses three. These counts are not independent significance tests.')
table('confirmation','Frozen Adult confirmation: five draws per cell, two fitting seeds per slice.','tab:confirmation','lrrrr',
      ['Partition','$K$','Size loss','$\\Delta_C$','$\\Delta_U$'],
      [[PN[r.partition],r.k,f'{r.size_query_linf:.6f}',f'{r.constrained_minus_size:+.6f}',f'{r.uniform_minus_size:+.6f}'] for r in cs.itertuples()],
      note='$\\Delta_C$: constrained minus size; $\\Delta_U$: uniform minus size. All configurations use the same 16,281 official reference records.')
table('external','Bank external replication: $K=5$, three fitting seeds and five draws per cell.','tab:external','llrr',
      ['Generator','Partition','Size loss','$\\Delta_C$'],
      [[GN[r.generator],PN[r.partition],f'{r.mean_size_loss:.6f}',f'{r.mean_constrained_minus_size:+.6f}'] for r in bs.itertuples()])
allm=df('all_development_method_rows.csv')
assert len(allm)==741
allm=allm[allm.generator.isin(GN)]
am=allm.groupby('method')[['query_linf_mean','delta_vs_size_mean','weight_l1_from_alpha']].mean()
assert allm.groupby('method').size().eq(54).all()
am.to_csv(T/'all_methods_summary.csv')
nice={'barycenter':'Finite entropic barycenter','entropy_calibration':'Entropy calibration','kernel_mean_matching':'Kernel mean matching',
      'logpool':'Finite geometric pool','moment_l2':'Moment least squares','predictive_evidence_bma':'Predictive evidence',
      'pseudo_bma_logscore':'Predictive-score softmax','query_minimax':'Unconstrained query minimax',
      'robust_query_calibration':'Robust query calibration','size':'Size','stacking_logscore':'Stacking',
      'uncertainty_gls':'Residual GLS','uniform':'Uniform'}
rows=[]
for n in ['size','uniform','moment_l2','entropy_calibration','uncertainty_gls','kernel_mean_matching','query_minimax','robust_query_calibration','pseudo_bma_logscore','predictive_evidence_bma','stacking_logscore','logpool','barycenter']:
    r=am.loc[n]
    access='Privileged scores' if n in ['pseudo_bma_logscore','predictive_evidence_bma','stacking_logscore'] else ('Models/counts' if n in ['size','uniform'] else 'Models/summaries')
    rows.append([nice[n],access,f'{r.query_linf_mean:.6f}',f'{r.delta_vs_size_mean:+.6f}',f'{r.weight_l1_from_alpha:.3f}'])
table('allmethods','All source candidate methods over the 54 corrected Adult core cells; descriptive assessment means.','tab:allmethods','llrrr',
      ['Method','Access class','Query-max','$\\Delta$ vs. size','Mean $\\|w-\\alpha\\|_1$'],rows,wide=True,
      note='Each method/cell averages five draws. The three independent-histogram controls are excluded. The representation-constrained challenger is a separately audited variant (Table~\\ref{tab:headline}). For nonlinear pools the last column refers to their recorded input weights, not an equivalent output client-mixture mass. Privileged scores, finite nonlinear supports, and different released summaries prevent an equal-information ranking. These are implementation outcomes, not optimal values for each literature family.')
u=df('adult_confirmation_utility.csv')
ug=u[u.scope=='global_alpha'].groupby(['method','learner'])[['brier','log_loss','auroc','auprc']].mean()
assert len(ug)==8
ug.to_csv(T/'utility_summary.csv')
mn={'size':'TSTR size','constrained':'TSTR constrained','uniform':'TSTR uniform','trtr_privileged':'TRTR privileged'}
rows=[]
for learner in ['logistic','extra_trees']:
    for method in ['size','constrained','uniform','trtr_privileged']:
        r=ug.loc[(method,learner)]
        rows.append(['Logistic' if learner=='logistic' else 'Extra-trees',mn[method],f'{r.brier:.6f}',f'{r.auroc:.6f}',f'{r.log_loss:.6f}'])
table('utility','Frozen same-person Adult utility at registered unequal training budgets; means over 12 cells.','tab:utility','llrrr',
      ['Learner','Data/rule','Brier $\\downarrow$','AUROC $\\uparrow$','Log loss $\\downarrow$'],rows,wide=True,
      note='TRTR train/tune/calibration: 21,148/4,880/3,254 real records. TSTR: 10,000/2,000/2,000 generated records. Scores use alpha-standardized official reference weights and source-specific calibration. No matched-size intrinsic utility effect is inferred. AUPRC and group-support results remain in the editable evidence tables.')
packages=[
 ('1','Fixed-target weighting','54 Adult core; 12 frozen cells; 12 Bank cells','No registered practical-gain slice','Other targets and model families'),
 ('2','Finite-pilot optimality','57 source LPs; six repeated-pilot cells','Finite optima; no fresh practical gain','Population/nonlinear optimum'),
 ('3','Subset composition','Algebra and saved effective-weight check','Mixtures collapse; negative closure','New within-subset estimator'),
 ('4','Synthetic size','Six checkpoints; three sizes; five draws','Draw range shrinks; error persists','Universal asymptotic floor'),
 ('5','Conditional sampling','Six student cells; 12 frozen service cells','Common filters pass; rare requests abstain','Arbitrary-condition fidelity'),
 ('6','Downstream utility','Logistic/trees; same-person scoring','TRTR better at larger recorded budget','Matched-size superiority/inferiority'),
 ('7','Joint-implied prediction','Six projected development cells','Exact Chow--Liu; approximate GMM','Universal support/exact continuous score'),
 ('8','Query diagnostics','175 queried diagnostics and frozen answers','Localized global and conditional failures','All-query/population TV accuracy'),
 ('9','Controlled ablations','12 projection; six summary-access cells','Repair matters; redundant-query null','Unrun component factorials'),
 ('10','Heterogeneity mechanism','Six fixed-quantity, equal-target cells','Skew achieved; no practical gain','Universal causal decomposition'),
 ('11','Conditional transfer','48 bound rows; 5,112 triangles','Finite algebra; low-support amplification','Population confirmation from identities'),
 ('12','Privacy/resources','Histogram; four PGM/four FLAIM; three payload cells','Main nonprivate; payload ratios above one','End-to-end DP, secure/WAN deployment')]
text='\\begin{table*}[t]\\centering\\footnotesize\n\\caption{Twelve completed work packages and their explicit exclusions. Experiment 3 is a negative/inapplicable expressivity result; the other eleven are bounded findings.}\\label{tab:packages}\n'
text+='\\begin{tabularx}{\\textwidth}{r p{.14\\textwidth} p{.23\\textwidth} Y Y}\\toprule\nNo. & Question & Completed scope & Finding & Exclusion\\\\\\midrule\n'
text+='\n'.join(' & '.join(r)+'\\\\' for r in packages)+'\n\\bottomrule\\end{tabularx}\\end{table*}\n'
(T/'packages.tex').write_text(text)

fig,axes=plt.subplots(1,3,figsize=(7.15,2.9),layout='constrained',sharey=True)
order=[('age',5),('age',10),('age_education',5),('age_education',10),('label_skew',5),('label_skew',10)]
for ax,g in zip(axes,['copula','chow_liu','mixed_gmm']):
    d=sl[sl.generator==g].set_index(['partition','k']).loc[order]
    y=np.arange(6);x=d.mean_paired_delta.to_numpy()
    ax.errorbar(x,y,xerr=np.vstack([x-d.min_paired_delta.to_numpy(),d.max_paired_delta.to_numpy()-x]),fmt='o',color=COLORS[g],capsize=2,ms=4)
    ax.axvline(0,color='#555555',lw=.7);ax.axvline(-.005,color='#b2182b',ls='--',lw=1)
    ax.set_title(GN[g].replace('--','–'),fontsize=9);ax.set_xlabel('Constrained − size')
    ax.grid(axis='x',alpha=.18)
axes[0].set_yticks(np.arange(6),[f'{PN[p]}, K={k}' for p,k in order]);axes[0].invert_yaxis()
savefig(fig,'development_slices')
fig,axs=plt.subplots(1,2,figsize=(7.15,2.8),layout='constrained')
for ax,ds,label in [(axs[0],cs,'Adult official holdout'),(axs[1],bs,'Bank external assessment')]:
    x=ds.constrained_minus_size.to_numpy() if ds is cs else ds.mean_constrained_minus_size.to_numpy()
    labs=[f'{PN[r.partition]}, K={r.k}' for r in ds.itertuples()] if ds is cs else [f'{GN[r.generator].replace("--","–")} / {PN[r.partition]}' for r in ds.itertuples()]
    ax.scatter(x,np.arange(len(x)),color='#2166ac',s=24)
    ax.set_yticks(np.arange(len(x)),labs);ax.invert_yaxis();ax.axvline(0,color='#555',lw=.7)
    ax.axvline(-.005,color='#b2182b',ls='--',lw=1);ax.set_xlim(-.0058,.0015);ax.grid(axis='x',alpha=.15)
    ax.set_title(label,fontsize=9);ax.set_xlabel('Constrained − size query-max')
savefig(fig,'confirmation_external')
sz=df('synthetic_size_by_family.csv');pi=df('pilot_size_by_family.csv')
fig,axs=plt.subplots(1,3,figsize=(7.15,2.6),layout='constrained')
for fam,c,label in [('chow_liu_age_k5',COLORS['chow_liu'],'Chow–Liu: age/K5'),('mixed_gmm_label_skew_k10',COLORS['mixed_gmm'],'GMM: label skew/K10')]:
    a=sz[sz.family==fam].sort_values('m');b=pi[pi.family==fam].sort_values('pilot_per_client')
    axs[0].plot(a.m,a.size_query_mean,'o-',color=c,label=label,ms=3)
    axs[1].plot(a.m,a.size_query_draw_range_mean,'o-',color=c,ms=3)
    axs[2].plot(b.pilot_per_client,b.same_target_fixed_reference_excess_mean,'o-',color=c,ms=3)
for ax,title in zip(axs,['Size-weighted query-max','Five-draw loss range','Finite-reference LP excess']):
    ax.set_xscale('log');ax.set_title(title,fontsize=8);ax.grid(alpha=.2)
axs[0].set_xlabel('Synthetic rows');axs[1].set_xlabel('Synthetic rows');axs[2].set_xlabel('Pilot rows/client')
axs[0].legend(loc='best',fontsize=6)
savefig(fig,'sampling_pilot')
fe=df('female_dependency_worst_query.csv')
assert len(fe)==12 and (fe.real_alpha_conditional==0).all()
assert np.isclose(fe.absolute_error.mean(),.375)
fe=fe.sort_values('cell')
labs=[]
for s in fe.cell:
    t=s.replace('copula_','').replace('age_education','Age+edu').replace('label_skew','Label').replace('age','Age').replace('_',' / ')
    labs.append(t)
fig,ax=plt.subplots(figsize=(3.48,3.1),layout='constrained')
ax.barh(np.arange(12),fe.synthetic,color='#ad5555',height=.65)
ax.set_yticks(np.arange(12),labs,fontsize=6);ax.invert_yaxis();ax.set_xlim(0,.44)
ax.set_xlabel('Generated frequency (real reference = 0)');ax.grid(axis='x',alpha=.16)
savefig(fig,'female_dependency')

manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(E.glob('*.csv'))}
summary={'development_core_cells':len(dc),'development_slices':len(sl),'confirmation_cells':len(cmeans),
         'confirmation_draw_rows':len(conf),'adult_development_delta':dc.paired_delta_vs_size.mean(),
         'adult_confirmation_delta':cdiff.mean(),'adult_confirmation_size_loss':cmeans['size'].mean(),
         'bank_delta':bs.mean_constrained_minus_size.mean(),'female_error_mean':fe.absolute_error.mean(),
         'source_csv_sha256':manifest,'operation':'saved-results aggregation only; no new experiments'}
(ROOT/'checks'/'evidence_reproduction.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='source_csv_sha256'},indent=2))
