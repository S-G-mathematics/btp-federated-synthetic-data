# Completion of the author-pack theory backlog

The file `evidence/THEORY_ONLY_BACKLOG.md` is preserved as a historical input. Its six tasks are treated in this manuscript as follows. Numbering below refers to the compiled 25 October 2026 version.

| Historical task | Completed mathematical treatment | Evidential limit |
|---|---|---|
| Finite-sample size fallback | Theorem 8, with pilot/summary/validation results 11–13; full proof and an explicit vacuity calculation | Sufficient certificate, not an experimentally evaluated or historically selected rule. |
| Representation sharpness | Proposition 1 proves the diameter and half-L1 bounds with an attaining example; Propositions 2–3 distinguish target error and identifiability | Client mass is not subgroup fairness or within-client accuracy. |
| Projected pushforwards | Proposition 14 proves normalization, preimage summation, query composition and TV contraction; finite and continuous cases distinguished | Exact only for exact mass/integral calculations; copula/GMM scores remain approximate. |
| Conditional transfer | Proposition 9, Counterexample 10, Propositions 15–16 and Corollary 17; routing identity and teacher/student distinction | Positive support and relevant joint queries required; observed identities are not population confidence statements. |
| Finite-support pooling approximation | Propositions 20–22 give restriction/smoothing, log-score perturbation and finite entropic transport objective bounds | Missing-support mass, score floors, regularization convention, metric and search gaps remain explicit. |
| Prospective complete privacy framework | Equation 46 and Proposition 23 specify adjacency, full transcript, independent randomization, postprocessing and composition; histogram sensitivity is derived | Conditional framework only. The main experiment remains nonprivate; its release ledger is not converted into a DP theorem. |

The full framework also includes non-IID assignment, fixed empirical targets, mixture convex-hull limits, model-only impossibility, oracle perturbation, regularization stability, fixed-allocation sampling, joint posteriors, Brier/risk transfer, and communication/compression accounting. Table IX maps the original programme to the paper.

There are 23 numbered mathematical statements (including two counterexamples) and 21 proof environments. The 991 deterministic finite-algebra checks support implementation and transcription review; they are neither proofs nor new experimental results. Known identities and elementary arguments are not claimed as novel foundational theorems.

No new experiment is required to support the retained bounded empirical claims. Claims outside that scope remain excluded rather than marked complete by this mathematical treatment.
