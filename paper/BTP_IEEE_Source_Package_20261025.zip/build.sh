#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build checks
python3 scripts/build_tables_figures.py > checks/table_build.log
python3 scripts/check_theory.py > checks/theory_check.log
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build BTP_IEEE_Manuscript.tex > checks/latex_build.log 2>&1
cp build/BTP_IEEE_Manuscript.pdf BTP_IEEE_Manuscript.pdf
printf '%s\n' 'Built BTP_IEEE_Manuscript.pdf; see checks/ for validation.'
