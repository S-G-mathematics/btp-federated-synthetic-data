WEIGHTED FEDERATED SYNTHETIC DATA GENERATION
MA4998P Project I — IIT Guwahati — November 2026

This is an editable report adaptation of BTP_IEEE_Manuscript(1).pdf using
the supplied ReportTemplateMA4998P.zip. It retains the report class, A4
paper, 12-point body text, 1.5 line spacing, institutional cover and logo,
certificate, abstract, contents, lists of figures/tables, and bibliography.

QUICK START
1. Edit student_details.tex to enter the verified roll number and the
   supervisor's exact name. The signature lines must be completed through
   the institution's actual approval process.
2. Compile from this directory with:
       bash build.sh
   Alternatively, upload this directory to Overleaf, select report.tex
   as the main document, and use pdfLaTeX with BibTeX.
3. The compiled result is BTP_MA4998P_Report.pdf.

BUILD REQUIREMENTS
A standard TeX Live installation with pdfLaTeX and BibTeX, the report
class, Latin Modern, AMS packages, graphicx, booktabs, array, tabularx,
multirow, longtable, setspace, bm, mathrsfs, tocbibind, url, xcolor,
microtype, etoolbox and hyperref. The submitted template's default report
margins are retained. Figures are already supplied as PDF; Python is not
required to compile the report.

For optional regeneration of the four figures:
    python scripts/rebuild_report_figures.py
This requires pandas, numpy and matplotlib and reads the supplied evidence
CSV files. It does not train models or run new experiments.

CONTENTS AND EVIDENCE BOUNDARIES
- chapters/, tables/, figures/: report text and presentation assets.
- references.bib: bibliography carried from the evidence manuscript.
- evidence/: archived result summaries, selection record and claim map.
- checks/: compilation and artifact-integrity checks, finite-algebra
  sanity-check output, and the original template source for provenance.
- scripts/check_theory.py: finite-algebra diagnostics, not a proof engine.
- scripts/verify_report.py: report/source integrity verification.

The manuscript and archived evidence, rather than earlier conversational
status messages, are the source for the reported frozen Adult and Bank
results. Negative and adverse outcomes have been retained. The twelve
work packages close only within the explicitly stated experimental scope.
The main pipeline is nonprivate; limited private baselines do not confer
an end-to-end privacy guarantee on it.

Appendix F adds the requested size-weight analysis after the experimental
campaign: exact-model optimality, a counterexample under model error,
an approximation bound, and a sufficient finite-workload certificate.
These are conditional mathematical results; they do not certify that size
weights are universally optimal for the fitted campaign models. No new
experiments were executed for the report conversion, and no experiment
was selected retrospectively using the added appendix.

This package includes the report and compact saved evidence. It does NOT
include the separate approximately 537 MB experimental archive, training
data, every checkpoint, or a complete experiment execution environment.
Do not describe this source zip as the full experimental repository.

TURNITIN AND ADMINISTRATIVE STATUS
No report was submitted to the BTP portal. No document was uploaded to
Turnitin. The available browser reached an institutional-account access
block; no genuine similarity or AI-content score was obtained. Both
certificate score fields are therefore blank. No local percentage is
offered as a substitute for Turnitin.

The notice supplied by the student says that both scores should ideally
be below 30%, and calls a score under 15% very good; it also requires
consultation with the supervisor about acceptable scores. These are
targets from the supplied notice, not guaranteed outcomes. Preserve
transparent attribution and the report's AI-assistance disclosure.
Review flagged passages for actual citation or authorship problems;
do not alter text merely to try to defeat an automated detector.

Use SUBMISSION_CHECKLIST.txt for the remaining human/institutional steps.
