#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build report.tex
bibtex build/report
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build report.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build report.tex
cp build/report.pdf BTP_MA4998P_Report.pdf
