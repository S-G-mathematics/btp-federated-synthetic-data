#!/usr/bin/env python3
"""Check artifact integrity; not a substitute for scientific or Turnitin review."""
import argparse
import hashlib
import json
import re
from pathlib import Path

import fitz


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--original', type=Path, default=None)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    tex_files = [root / 'report.tex', *sorted((root / 'chapters').glob('*.tex')),
                 *sorted((root / 'tables').glob('*.tex'))]
    source = '\n'.join(p.read_text() for p in tex_files)
    labels = set(re.findall(r'\\label\{([^}]+)\}', source))
    refs = set(re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', source))
    bib_keys = set(re.findall(r'@\w+\s*\{\s*([^,]+)', (root / 'references.bib').read_text()))
    cited = set()
    for group in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}', source):
        cited.update(k.strip() for k in group.split(','))
    log = (root / 'build/report.log').read_text()
    issues = [line for line in log.splitlines()
              if any(s in line for s in ('Overfull', 'undefined', 'too large', 'LaTeX Warning'))]
    pdf = root / 'BTP_MA4998P_Report.pdf'
    doc = fitz.open(pdf)
    out_of_bounds = []
    empty_pages = []
    for i, page in enumerate(doc):
        if not page.get_text().strip():
            empty_pages.append(i + 1)
        for block in page.get_text('blocks'):
            if not (page.rect + (-1, -1, 1, 1)).contains(fitz.Rect(block[:4])):
                out_of_bounds.append(i + 1)
    package_source = (root / 'tables/packages.tex').read_text()
    packages = [int(n) for n in re.findall(r'^([0-9]+) &', package_source, flags=re.M)]
    details = (root / 'student_details.tex').read_text()
    result = {
        'scope': 'document integrity only; no Turnitin score and no new experiment',
        'pdf_sha256': digest(pdf),
        'pdf_pages': len(doc),
        'all_pages_a4': all(abs(p.rect.width - 595.276) < 1 and abs(p.rect.height - 841.89) < 1 for p in doc),
        'empty_pages': empty_pages,
        'out_of_page_text': out_of_bounds,
        'compile_issues': issues,
        'unresolved_source_references': sorted(refs - labels),
        'missing_bibliography_keys': sorted(cited - bib_keys),
        'bibliography_entries': len(bib_keys),
        'cited_entries': len(cited),
        'work_packages': packages,
        'mathematical_statements': len(re.findall(r'\\begin\{(?:theorem|proposition|corollary|example|lemma)\}', source)),
        'proof_environments': source.count('\\begin{proof}'),
        'scores_left_blank': all(re.search(r'\\newcommand\{\\' + name + r'\}\{\\rule', details)
                                 for name in ('SimilarityScore', 'AIContentScore')),
        'turnitin_similarity_score': None,
        'turnitin_ai_score': None,
        'submitted': False,
    }
    if args.original:
        old_source = '\n'.join(p.read_text() for p in (args.original / 'sections').glob('*.tex'))
        old_labels = set(re.findall(r'\\label\{([^}]+)\}', old_source))
        result['original_section_labels_missing'] = sorted(old_labels - labels)
        originals = sorted((args.original / 'evidence').glob('*'))
        result['original_evidence_files_compared'] = sum(p.is_file() for p in originals)
        result['evidence_mismatches'] = [p.name for p in originals if p.is_file()
            and (not (root / 'evidence' / p.name).exists()
                 or digest(p) != digest(root / 'evidence' / p.name))]
    checks = [result['all_pages_a4'], not empty_pages, not out_of_bounds, not issues,
              not (refs - labels), not (cited - bib_keys), packages == list(range(1, 13)),
              not result.get('original_section_labels_missing'), not result.get('evidence_mismatches')]
    result['integrity_checks_passed'] = all(checks)
    output = root / 'checks/report_integrity.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if all(checks) else 1)


if __name__ == '__main__':
    main()
